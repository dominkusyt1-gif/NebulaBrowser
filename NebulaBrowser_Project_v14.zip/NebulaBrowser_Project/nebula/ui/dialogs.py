from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
class SettingsDialog(QDialog):
    def __init__(self,parent,cfg):
        super().__init__(parent);self.setWindowTitle("Ustawienia Nebula");self.setMinimumWidth(440);f=QFormLayout(self)
        self.engine=QComboBox();self.engine.addItems(["Google","Bing","DuckDuckGo"]);self.engine.setCurrentText(cfg["search"]);f.addRow("Wyszukiwarka",self.engine)
        self.home=QLineEdit(cfg["home"]);f.addRow("Strona główna",self.home)
        self.accent=QComboBox()
        for n,c in [("Fioletowy","#9b6cff"),("Niebieski","#568bff"),("Turkusowy","#30cdb4"),("Różowy","#ef6bc4")]:self.accent.addItem(n,c)
        self.accent.setCurrentIndex(max(0,self.accent.findData(cfg["accent"])));f.addRow("Kolor akcentu",self.accent)
        self.folder=QLineEdit(cfg["download"]);pick=QPushButton("Wybierz…");pick.clicked.connect(self.pick)
        row=QHBoxLayout();row.addWidget(self.folder,1);row.addWidget(pick);f.addRow("Folder pobierania",row)
        self.ask=QCheckBox("Pytaj, gdzie zapisać każdy plik");self.ask.setChecked(cfg["ask_download"]);f.addRow("",self.ask)
        self.js=QCheckBox("Włącz JavaScript");self.js.setChecked(cfg["javascript"]);f.addRow("",self.js)
        b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);b.accepted.connect(self.accept);b.rejected.connect(self.reject);f.addRow(b)
    def pick(self):
        p=QFileDialog.getExistingDirectory(self,"Folder pobierania",self.folder.text())
        if p:self.folder.setText(p)
    def values(self):
        h=self.home.text().strip() or "https://www.google.com"
        if not h.startswith(("http://","https://")):h="https://"+h
        return {"search":self.engine.currentText(),"home":h,"accent":self.accent.currentData(),"download":self.folder.text().strip(),"ask_download":self.ask.isChecked(),"javascript":self.js.isChecked()}
class ListDialog(QDialog):
    def __init__(self,parent,title,rows,remove=None):
        super().__init__(parent);self.setWindowTitle(title);self.resize(720,450);v=QVBoxLayout(self);self.items=QListWidget()
        for title,url,*extra in rows:
            it=QListWidgetItem(f"{title or url}\n{url}");it.setData(Qt.ItemDataRole.UserRole,url);self.items.addItem(it)
        v.addWidget(self.items,1);bar=QHBoxLayout();self.open_btn=QPushButton("Otwórz");bar.addWidget(self.open_btn)
        if remove:
            b=QPushButton("Usuń");bar.addWidget(b);b.clicked.connect(lambda:remove(self.items))
        bar.addStretch();close=QPushButton("Zamknij");bar.addWidget(close);v.addLayout(bar);close.clicked.connect(self.reject)
