from pathlib import Path
import sys
from urllib.parse import quote_plus
from PySide6.QtCore import QUrl,QUrlQuery,Qt,QThread,Signal
from PySide6.QtGui import QKeySequence,QShortcut,QCursor,QIcon
from PySide6.QtWidgets import *
from PySide6.QtWebEngineCore import QWebEngineProfile,QWebEngineSettings
from nebula.config import DATA,load,save
from nebula.storage.store import Store
from nebula.core.view import BrowserView
from nebula.ui.new_tab import make_html,add_shortcut
from nebula.ui.dialogs import SettingsDialog,ListDialog
class UpdateCheckWorker(QThread):
    finished_check = Signal(str, str, str)
    failed_check = Signal(str)
    def __init__(self, api_url):
        super().__init__()
        self.api_url = api_url
    def run(self):
        try:
            import json, urllib.request
            request=urllib.request.Request(self.api_url,headers={"User-Agent":"NebulaBrowser-Updater"})
            with urllib.request.urlopen(request,timeout=10) as response:
                data=json.loads(response.read().decode("utf-8"))
            latest=str(data.get("tag_name") or data.get("version") or "nieznana")
            download=str(data.get("html_url") or data.get("download_url") or "")
            self.finished_check.emit(latest, download, "")
        except Exception as exc:
            self.failed_check.emit(str(exc))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__();self.cfg=load();self.store=Store();self.setWindowTitle("Nebula Browser");self.resize(1440,900);self.setMinimumSize(1000,650);self._restoring=True
        bundle_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
        icon_path = bundle_root / "nebula.ico"
        if icon_path.exists(): self.setWindowIcon(QIcon(str(icon_path)))
        self.apply_process_priority(self.cfg.get("process_priority_low",False))
        self.profile=QWebEngineProfile("NebulaProfile",self);self.profile.setPersistentStoragePath(str(DATA/"web_data"));self.profile.setCachePath(str(DATA/"cache"));self.profile.setHttpCacheMaximumSize(int(self.cfg.get("cache_mb",256))*1024*1024)
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies);self.profile.downloadRequested.connect(self.download)
        shell=QWidget();outer=QVBoxLayout(shell);outer.setContentsMargins(10,10,10,10);outer.setSpacing(7)
        main=QVBoxLayout()
        # Separate visible tab strip: tabs sit above the address bar, like a modern desktop browser.
        self.top_tabs=QTabBar()
        self.top_tabs.setMovable(True)
        self.top_tabs.setTabsClosable(False)
        self.top_tabs.setExpanding(False)
        self.top_tabs.currentChanged.connect(self._top_tab_changed)
        self.top_tabs.tabCloseRequested.connect(self.close_tab)
        main.addWidget(self.top_tabs)
        bar=QHBoxLayout()
        def btn(t,tip,fn):
            b=QPushButton(t);b.setToolTip(tip);b.setFixedWidth(38);b.clicked.connect(fn);return b
        bar.addWidget(btn("←","Wstecz",lambda:self.current() and self.current().back()));bar.addWidget(btn("→","Dalej",lambda:self.current() and self.current().forward()));bar.addWidget(btn("⟳","Odśwież",lambda:self.current() and self.current().reload()));bar.addWidget(btn("⌂","Start",self.home))
        self.address=QLineEdit();self.address.setPlaceholderText("Wyszukaj lub wpisz adres strony");self.address.returnPressed.connect(self.navigate);bar.addWidget(self.address,1)
        bar.addWidget(btn("☆","Dodaj zakładkę",self.add_bookmark));bar.addWidget(btn("+","Nowa karta",self.new_tab));bar.addWidget(btn("⋯","Menu",self.menu));main.addLayout(bar)
        self.progress=QProgressBar();self.progress.setTextVisible(False);self.progress.setFixedHeight(3);self.progress.hide();main.addWidget(self.progress)
        self.tabs=QTabWidget();self.tabs.setDocumentMode(True);self.tabs.setMovable(True);self.tabs.setTabsClosable(False);self.tabs.tabBar().hide();self.tabs.currentChanged.connect(self.tab_changed);main.addWidget(self.tabs,1)
        content=QWidget();content.setLayout(main);outer.addWidget(content,1);self.setCentralWidget(shell);self.style()
        for key,fn in [("Ctrl+T",self.new_tab),("Ctrl+W",lambda:self.close_tab(self.tabs.currentIndex())),("Ctrl+L",self.focus),("Ctrl+D",self.add_bookmark),("Ctrl+H",self.history),("Ctrl+B",self.bookmarks),("Ctrl+R",lambda:self.current() and self.current().reload())]:QShortcut(QKeySequence(key),self,activated=fn)
        saved_tabs=self.cfg.get("session_tabs",[]) if self.cfg.get("restore_session", True) else []
        if saved_tabs:
            for saved_url in saved_tabs:
                if isinstance(saved_url,str) and saved_url.startswith(("http://","https://")):
                    self.add_tab(QUrl(saved_url))
            if self.tabs.count()==0:self.new_tab()
        else:
            self.new_tab()
        self._restoring=False
        if self.cfg.get("update_notifications",False) and self.cfg.get("update_release_api","").strip():
            from PySide6.QtCore import QTimer
            QTimer.singleShot(2500, lambda: self.check_for_updates(silent=True))
    @staticmethod
    def apply_process_priority(low_priority):
        if sys.platform != "win32":
            return
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            priority = 0x00004000 if low_priority else 0x00000020  # BELOW_NORMAL / NORMAL
            kernel32.SetPriorityClass(kernel32.GetCurrentProcess(), priority)
        except Exception:
            pass

    def _top_tab_changed(self, index):
        if 0 <= index < self.tabs.count() and self.tabs.currentIndex() != index:
            self.tabs.setCurrentIndex(index)

    def _sync_top_tabs(self):
        # Sync labels, site icons, and close buttons with the internal page stack.
        while self.top_tabs.count() > self.tabs.count():
            self.top_tabs.removeTab(self.top_tabs.count() - 1)
        while self.top_tabs.count() < self.tabs.count():
            idx=self.top_tabs.addTab(self.tabs.tabText(self.top_tabs.count()))
            self.top_tabs.setTabToolTip(idx,self.tabs.tabToolTip(idx))
        for i in range(self.tabs.count()):
            widget=self.tabs.widget(i)
            title=self.tabs.tabText(i)
            self.top_tabs.setTabText(i,title)
            self.top_tabs.setTabToolTip(i,self.tabs.tabToolTip(i))
            if isinstance(widget,BrowserView):
                icon=widget.icon()
                if not icon.isNull():
                    self.top_tabs.setTabIcon(i,icon)
            else:
                self.top_tabs.setTabIcon(i,QIcon.fromTheme("preferences-system"))
            close_btn=self.top_tabs.tabButton(i,QTabBar.ButtonPosition.RightSide)
            if close_btn is None:
                close_btn=QPushButton("×")
                close_btn.setObjectName("tabClose")
                close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                close_btn.setFixedSize(24,24)
                close_btn.setToolTip("Zamknij kartę")
                close_btn.clicked.connect(lambda checked=False, button=close_btn: self.close_tab(self._tab_index_for_close_button(button)))
                self.top_tabs.setTabButton(i,QTabBar.ButtonPosition.RightSide,close_btn)
        if self.tabs.count():
            self.top_tabs.blockSignals(True)
            self.top_tabs.setCurrentIndex(self.tabs.currentIndex())
            self.top_tabs.blockSignals(False)

    def _tab_index_for_close_button(self, button):
        for index in range(self.top_tabs.count()):
            if self.top_tabs.tabButton(index, QTabBar.ButtonPosition.RightSide) is button:
                return index
        return -1

    def current(self):
        widget=self.tabs.currentWidget()
        return widget if isinstance(widget,BrowserView) else None
    def new_tab(self):return self.add_tab()
    def add_tab(self,url=None):
        v=BrowserView(self,self.profile)
        settings=v.page().settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, self.cfg.get("javascript",True))
        settings.setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages, self.cfg.get("load_images",True))
        v.urlChanged.connect(lambda u,w=v:self.store.visit(u.toString(),w.title()));i=self.tabs.addTab(v,"Nowa karta");self.tabs.setCurrentIndex(i);self._sync_top_tabs()
        if url and url.toString() not in ("about:blank",""):v.setUrl(url)
        else:v.setHtml(make_html(self.store.shortcuts(), self.cfg["accent"], self.cfg),QUrl("https://nowa-karta.nebula/"))
        return v
    def close_tab(self,i):
        if i < 0 or i >= self.tabs.count():
            return
        if self.tabs.count()==1:
            self.home();return
        w=self.tabs.widget(i);self.tabs.removeTab(i);w.deleteLater();self._sync_top_tabs()
    def navigate(self):
        t=self.address.text().strip()
        if not t:return
        if " " in t or ("." not in t and t.lower()!="localhost"):
            url={"Google":"https://www.google.com/search?q=","Bing":"https://www.bing.com/search?q=","DuckDuckGo":"https://duckduckgo.com/?q="}[self.cfg["search"]]+quote_plus(t)
        else:url=t if t.startswith(("http://","https://")) else "https://"+t
        v=self.current()
        if v is None:
            v=self.add_tab()
        v.setUrl(QUrl(url))
    def home(self):
        v=self.current()
        if not v:
            v=self.add_tab()
        target=(self.cfg.get("home") or "https://www.google.com").strip()
        if not target.startswith(("http://","https://")):
            target="https://"+target
        v.setUrl(QUrl(target))
    def handle_add_shortcut(self, title, url):
        url=(url or "").strip()
        if not url.startswith(("http://","https://")):
            return
        self.store.add_shortcut(url, title or url)
        v=self.current()
        if v:
            v.setHtml(make_html(self.store.shortcuts(), self.cfg["accent"], self.cfg),QUrl("https://nowa-karta.nebula/"))
        self.statusBar().showMessage("Dodano skrót do Szybkiego startu",3000)

    def handle_start_search(self, query):
        query=(query or "").strip()
        if not query:
            return
        if " " in query or ("." not in query and query.lower()!="localhost"):
            url={"Google":"https://www.google.com/search?q=","Bing":"https://www.bing.com/search?q=","DuckDuckGo":"https://duckduckgo.com/?q="}[self.cfg["search"]]+quote_plus(query)
        else:
            url=query if query.startswith(("http://","https://")) else "https://"+query
        v=self.current()
        if v:
            v.setUrl(QUrl(url))

    def url_changed(self,v,u):
        if v is self.current() and "nowa-karta.nebula" not in u.toString() and u.toString()!="about:blank":
            self.address.setText(u.toString())

    def title_changed(self,v,t):
        i=self.tabs.indexOf(v)
        if i>=0:
            shown = "Nowa karta" if "nowa-karta.nebula" in v.url().toString() else (t or "Nowa karta")
            self.tabs.setTabText(i,shown[:22]);self.tabs.setTabToolTip(i, "" if "nowa-karta.nebula" in v.url().toString() else v.url().toString());self._sync_top_tabs()
        if v is self.current():self.setWindowTitle((t or "Nowa karta" if "nowa-karta.nebula" in v.url().toString() else t or "Nebula Browser")+" — Nebula Browser")
    def tab_changed(self,*_):
        self._sync_top_tabs()
        v=self.current()
        self.address.setText(v.url().toString() if v and "nowa-karta.nebula" not in v.url().toString() and v.url().toString()!="about:blank" else "")
    def focus(self):self.address.setFocus();self.address.selectAll()
    def add_bookmark(self):
        v=self.current()
        if v and v.url().scheme() in ("http","https"):self.store.add_bookmark(v.url().toString(),v.title());self.statusBar().showMessage("Dodano zakładkę",2500)
    def show_list(self,title,rows,remove=None):
        # Internal browser utility pages open as tabs instead of separate dialogs.
        html = ['<!doctype html><html lang="pl"><meta charset="utf-8"><style>',
                "body{font-family:Segoe UI,Arial;background:#100e1b;color:#f4efff;padding:28px}",
                "h1{color:#d8c7ff}a{color:#bca0ff}li{padding:10px;margin:8px 0;background:#211b32;border-radius:10px}",
                "small{color:#a99cbd}</style><h1>"+title+"</h1><ul>"]
        for name,url,*extra in rows:
            safe_name = str(name or url).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
            safe_url = str(url).replace("&","&amp;").replace('"',"&quot;").replace("<","&lt;").replace(">","&gt;")
            html.append(f'<li><a href="{safe_url}">{safe_name}</a><br><small>{safe_url}</small></li>')
        if not rows: html.append("<li>Brak zapisanych pozycji.</li>")
        html.append("</ul></html>")
        view=self.add_tab()
        view.setHtml("".join(html),QUrl("https://nowa-karta.nebula/"))
        idx=self.tabs.indexOf(view); self.tabs.setTabText(idx,title); self._sync_top_tabs()
    def open_item(self,d):
        if d.items.currentItem():self.add_tab(QUrl(d.items.currentItem().data(Qt.ItemDataRole.UserRole)));d.accept()
    def history(self):self.show_list("Historia",[(t or u,u,dt) for t,u,dt in self.store.history()])
    def bookmarks(self):self.show_list("Zakładki",self.store.bookmarks(),self.remove_bookmark)
    def remove_bookmark(self,l):
        if l.currentItem():self.store.remove_bookmark(l.currentItem().data(Qt.ItemDataRole.UserRole));l.takeItem(l.currentRow())
    def downloads(self):
        folder=Path(self.cfg["download"]).expanduser()
        rows=[]
        if folder.exists():
            for item in sorted(folder.iterdir(), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True):
                if item.is_file():
                    rows.append((item.name, item.as_uri()))
        self.show_list("Pobrane pliki", rows)

    def menu(self):
        m=QMenu(self)
        m.setMinimumWidth(245)
        sections = [
            ("＋  Nowa karta", self.new_tab),
            ("⌂  Strona startowa", self.home),
            ("☆  Dodaj bieżącą stronę do zakładek", self.add_bookmark),
            ("✦  Dodaj skrót do Szybkiego startu", self.add_shortcut),
            ("", None),
            ("▣  Zakładki", self.bookmarks),
            ("◷  Historia", self.history),
            ("↓  Pobrane pliki", self.downloads),
            ("", None),
            ("⚙  Ustawienia", self.settings),
        ]
        for label,fn in sections:
            if not label:
                m.addSeparator()
            else:
                action=m.addAction(label)
                action.triggered.connect(fn)
        m.addSeparator()
        quit_action=m.addAction("✕  Zamknij Nebula Browser")
        quit_action.triggered.connect(self.close)
        m.exec(QCursor.pos())
    def add_shortcut(self):
        item=add_shortcut(self)
        if item:
            self.store.add_shortcut(item[1],item[0])
            v=self.current()
            if v and "nowa-karta.nebula" in v.url().toString():
                v.setHtml(make_html(self.store.shortcuts(), self.cfg["accent"], self.cfg),QUrl("https://nowa-karta.nebula/"))
            else:
                self.home()
            self.statusBar().showMessage("Dodano skrót do Szybkiego startu",3000)
    def clear_history(self):
        if QMessageBox.question(self,"Historia","Wyczyścić historię?")==QMessageBox.StandardButton.Yes:self.store.clear_history()
    def settings(self):
        # Categorized settings page; each option below is wired to actual browser behavior.
        page=QWidget(); root=QVBoxLayout(page)
        heading=QLabel("Ustawienia Nebula Browser")
        heading.setStyleSheet("font-size:22px;font-weight:700;padding:8px")
        root.addWidget(heading)
        categories=QTabWidget(); root.addWidget(categories,1)

        general=QWidget(); gf=QFormLayout(general)
        engine=QComboBox(); engine.addItems(["Google","Bing","DuckDuckGo"]); engine.setCurrentText(self.cfg.get("search","Google")); gf.addRow("Wyszukiwarka",engine)
        home=QLineEdit(self.cfg.get("home","https://www.google.com")); gf.addRow("Strona główna",home)
        restore=QCheckBox("Przywracaj otwarte strony po uruchomieniu"); restore.setChecked(self.cfg.get("restore_session",True)); gf.addRow("Sesja",restore)
        categories.addTab(general,"Ogólne")

        appearance=QWidget(); af=QFormLayout(appearance)
        accent=QComboBox()
        for n,c in [("Fioletowy","#9b6cff"),("Niebieski","#568bff"),("Turkusowy","#30cdb4"),("Różowy","#ef6bc4")]: accent.addItem(n,c)
        accent.setCurrentIndex(max(0,accent.findData(self.cfg.get("accent","#9b6cff")))); af.addRow("Kolor akcentu",accent)
        theme=QComboBox(); theme.addItem("Ciemny","dark"); theme.addItem("Czarny","black"); theme.setCurrentIndex(max(0,theme.findData(self.cfg.get("theme","black")))); af.addRow("Motyw interfejsu",theme)
        tab_width=QComboBox(); tab_width.addItem("Kompaktowe","compact"); tab_width.addItem("Długie","long"); tab_width.addItem("Bardzo długie","extra"); tab_width.setCurrentIndex(max(0,tab_width.findData(self.cfg.get("tab_width","extra")))); af.addRow("Szerokość kart",tab_width)
        categories.addTab(appearance,"Wygląd")

        performance=QWidget(); pf=QFormLayout(performance)
        animated=QCheckBox("Animowane tło na nowej karcie"); animated.setChecked(self.cfg.get("animated_background",True)); pf.addRow("Tło",animated)
        low_effects=QCheckBox("Tryb wydajności: ogranicz rozmycia i cienie"); low_effects.setChecked(self.cfg.get("low_effects",False)); pf.addRow("Wydajność",low_effects)
        density=QComboBox(); density.addItem("Mało gwiazd — najszybciej","low"); density.addItem("Średnio","medium"); density.addItem("Dużo gwiazd — efektowniej","high"); density.setCurrentIndex(max(0,density.findData(self.cfg.get("star_density","medium")))); pf.addRow("Gęstość gwiazd",density)
        saver=QCheckBox("Oszczędzanie zasobów (bez animacji w nowych kartach)"); saver.setChecked(self.cfg.get("resource_saver",False)); pf.addRow("Oszczędzanie zasobów",saver)
        priority_low=QCheckBox("Niższy priorytet procesu Nebula w Windows"); priority_low.setChecked(self.cfg.get("process_priority_low",False)); pf.addRow("Priorytet CPU",priority_low)
        images=QCheckBox("Ładuj obrazy na stronach internetowych"); images.setChecked(self.cfg.get("load_images",True)); pf.addRow("Obrazy stron",images)
        cache=QComboBox()
        for mb in (64,128,256,512): cache.addItem(f"{mb} MB",mb)
        cache.setCurrentIndex(max(0,cache.findData(int(self.cfg.get("cache_mb",256))))); pf.addRow("Limit pamięci podręcznej",cache)
        note=QLabel("Zmiany wydajności dotyczą karty startowej. Mniej efektów oznacza mniejsze obciążenie procesora i grafiki."); note.setWordWrap(True); pf.addRow(note)
        categories.addTab(performance,"Wydajność")

        privacy=QWidget(); prf=QFormLayout(privacy)
        js=QCheckBox("Włącz JavaScript (niektóre strony go wymagają)"); js.setChecked(self.cfg.get("javascript",True)); prf.addRow("Strony",js)
        folder=QLineEdit(self.cfg.get("download",str(Path.home()/"Downloads"))); choose=QPushButton("Wybierz folder…")
        choose.clicked.connect(lambda: folder.setText(QFileDialog.getExistingDirectory(self,"Folder pobierania",folder.text()) or folder.text()))
        folder_row=QHBoxLayout(); folder_row.addWidget(folder,1); folder_row.addWidget(choose); prf.addRow("Folder pobierania",folder_row)
        ask=QCheckBox("Pytaj przed zapisaniem każdego pliku"); ask.setChecked(self.cfg.get("ask_download",False)); prf.addRow("Pobieranie",ask)
        categories.addTab(privacy,"Strony i pobieranie")

        updates_page=QWidget(); uf=QFormLayout(updates_page)
        updates=QCheckBox("Włącz powiadomienia o aktualizacjach (za moją zgodą)"); updates.setChecked(self.cfg.get("update_notifications",False)); uf.addRow("Aktualizacje",updates)
        release_api=QLineEdit(self.cfg.get("update_release_api","")); release_api.setPlaceholderText("GitHub API, np. https://api.github.com/repos/USER/REPO/releases/latest"); uf.addRow("Adres API wydań",release_api)
        check_updates=QPushButton("Sprawdź aktualizacje…"); check_updates.clicked.connect(lambda: (self.cfg.update({"update_release_api":release_api.text().strip(),"update_notifications":updates.isChecked()}), save(self.cfg), self.check_for_updates())); uf.addRow(check_updates)
        info=QLabel("Po zaznaczeniu powiadomień Nebula sprawdzi wydanie przy starcie. Wpisz adres API oficjalnego repozytorium wydań. Pobranie/instalacja wymaga Twojego potwierdzenia."); info.setWordWrap(True); uf.addRow(info)
        categories.addTab(updates_page,"Aktualizacje")

        buttons=QHBoxLayout(); buttons.addStretch(); save_btn=QPushButton("Zapisz ustawienia"); buttons.addWidget(save_btn); root.addLayout(buttons)
        def save_settings():
            h=home.text().strip() or "https://www.google.com"
            if not h.startswith(("https://","http://")): h="https://"+h
            download_path=folder.text().strip() or str(Path.home()/"Downloads")
            self.cfg.update({"search":engine.currentText(),"home":h,"accent":accent.currentData(),
                "download":download_path,"ask_download":ask.isChecked(),"javascript":js.isChecked(),
                "restore_session":restore.isChecked(),"theme":theme.currentData(),"tab_width":tab_width.currentData(),
                "update_notifications":updates.isChecked(),"update_release_api":release_api.text().strip(),"animated_background":animated.isChecked(),
                "low_effects":low_effects.isChecked(),"star_density":density.currentData(),
                "resource_saver":saver.isChecked(),"load_images":images.isChecked(),"cache_mb":cache.currentData(),"process_priority_low":priority_low.isChecked()})
            save(self.cfg); self.style(); self.apply_process_priority(self.cfg["process_priority_low"])
            for i in range(self.tabs.count()):
                widget=self.tabs.widget(i)
                if isinstance(widget,BrowserView):
                    widget.page().settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled,self.cfg["javascript"])
                    widget.page().settings().setAttribute(QWebEngineSettings.WebAttribute.AutoLoadImages,self.cfg["load_images"])
                    if "nowa-karta.nebula" in widget.url().toString():
                        widget.setHtml(make_html(self.store.shortcuts(),self.cfg["accent"],self.cfg),QUrl("https://nowa-karta.nebula/"))
            self.profile.setHttpCacheMaximumSize(int(self.cfg["cache_mb"])*1024*1024)
            self.statusBar().showMessage("Ustawienia zapisane i zastosowane",3000)
        save_btn.clicked.connect(save_settings)
        idx=self.tabs.addTab(page,"Ustawienia"); self.tabs.setCurrentIndex(idx); self._sync_top_tabs()
    def check_for_updates(self, silent=False):
        self._update_silent = silent
        url=self.cfg.get("update_release_api","").strip()
        if not url:
            QMessageBox.information(self,"Aktualizacje Nebula Browser",
                "Najpierw wpisz adres API oficjalnych wydań w Ustawienia → Aktualizacje.\n"
                "Dla GitHub użyj formatu: https://api.github.com/repos/OWNER/REPO/releases/latest")
            return
        if getattr(self,"_update_worker",None) is not None and self._update_worker.isRunning():
            self.statusBar().showMessage("Sprawdzanie aktualizacji już trwa…",3000)
            return
        self.statusBar().showMessage("Sprawdzanie aktualizacji w tle…",5000)
        self._update_worker=UpdateCheckWorker(url)
        self._update_worker.finished_check.connect(self._update_result)
        self._update_worker.failed_check.connect(self._update_error)
        self._update_worker.start()

    def _update_result(self, latest, download, _unused=""):
        current=str(self.cfg.get("version","0.8.0"))
        if latest.lstrip("vV") == current.lstrip("vV"):
            if not getattr(self,"_update_silent",False):
                QMessageBox.information(self,"Aktualizacje Nebula Browser",f"Masz najnowszą wersję ({current}).")
        else:
            answer=QMessageBox.question(self,"Dostępna aktualizacja",
                f"Znaleziono wersję {latest}.\nCzy otworzyć stronę pobierania?",
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)
            if answer==QMessageBox.StandardButton.Yes and download:
                from PySide6.QtGui import QDesktopServices
                QDesktopServices.openUrl(QUrl(download))
            elif not download:
                QMessageBox.information(self,"Aktualizacja","Repozytorium nie zwróciło adresu strony pobierania.")

    def _update_error(self, message):
        QMessageBox.warning(self,"Nie udało się sprawdzić aktualizacji",
                            "Sprawdź połączenie internetowe i adres API wydań.\n"+message)

    def download(self,item):
        folder=Path(self.cfg["download"]).expanduser();folder.mkdir(parents=True,exist_ok=True);target=folder/(item.downloadFileName() or "pobrany_plik")
        if self.cfg["ask_download"]:
            p,_=QFileDialog.getSaveFileName(self,"Zapisz plik",str(target))
            if not p:item.cancel();return
            target=Path(p)
        elif target.exists():
            stem,suf=target.stem,target.suffix;n=1
            while target.exists():target=folder/f"{stem} ({n}){suf}";n+=1
        item.setDownloadDirectory(str(target.parent));item.setDownloadFileName(target.name);item.accept();self.statusBar().showMessage("Pobieranie: "+target.name,4000)
    def style(self):
        a=self.cfg["accent"]
        bg = "#100e1b" if self.cfg.get("theme") == "dark" else "#000000"
        panel = "#171426" if self.cfg.get("theme") == "dark" else "#101014"
        tab_width = {"compact":105,"long":175,"extra":220}.get(self.cfg.get("tab_width","extra"),220)
        self.top_tabs.setStyleSheet(f"QTabBar::tab{{min-width:{tab_width}px;padding-right:34px}} QTabBar::close-button{{image:none;subcontrol-position:right;subcontrol-origin:padding;width:18px;height:18px;margin-right:8px;border-radius:9px;background:transparent}} QTabBar::close-button:hover{{background:{a}}}")
        self.setStyleSheet(f"""QMainWindow,QWidget{{background:{bg};color:#f4efff;font-family:'Segoe UI';font-size:13px}}
        
        QPushButton{{background:#211b32;color:#e9e0ff;border:1px solid #302644;border-radius:10px;padding:9px}}QPushButton:hover,QTabBar::tab:selected,QMenu::item:selected{{background:{a};color:white}}
        
        QLineEdit{{background:{panel};color:#f6f0ff;border:1px solid #49385f;border-radius:15px;padding:12px 15px;font-size:14px}}QLineEdit:focus{{border:1px solid {a}}}
        QPushButton#tabClose{{background:transparent;color:#ffffff;border:0;border-radius:12px;font-size:23px;font-weight:400;padding:0;margin-right:5px}}QPushButton#tabClose:hover{{background:{a};color:white}}QTabWidget::pane{{border:1px solid {a};border-radius:12px}}QTabBar::tab{{background:#1a1627;color:#c9bddf;padding:12px 38px 12px 16px;margin-right:6px;margin-bottom:0;border:1px solid #5e5b69;border-bottom:2px solid #5e5b69;border-top-left-radius:22px;border-top-right-radius:22px;min-width:120px}}QTabBar::tab:selected{{background:#1c1d26;color:#ffffff;border:2px solid {a};border-bottom-color:#1c1d26}}QTabBar::close-button{{subcontrol-position:right;image:none;width:10px;height:10px}}
        QProgressBar{{border:0;background:{panel}}}QProgressBar::chunk{{background:{a}}}QMenu,QDialog{{background:{panel};color:#f4efff;border:1px solid #49385f}}QListWidget{{background:#151221;color:#f4efff;border:1px solid #49385f;border-radius:8px}}QComboBox{{background:#211b32;color:#f4efff;padding:7px}}QStatusBar{{background:#171426;color:#9c91b6}}""")
    def closeEvent(self,e):
        session=[]
        for i in range(self.tabs.count()):
            w=self.tabs.widget(i)
            if isinstance(w,BrowserView):
                u=w.url().toString()
                if u.startswith(("http://","https://")) and "nowa-karta.nebula" not in u:
                    session.append(u)
        self.cfg["session_tabs"]=session if self.cfg.get("restore_session",True) else []
        save(self.cfg);e.accept()
