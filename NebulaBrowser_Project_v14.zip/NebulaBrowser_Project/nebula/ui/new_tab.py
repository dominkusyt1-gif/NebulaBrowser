from PySide6.QtWidgets import QDialog, QFormLayout, QLineEdit, QDialogButtonBox
from html import escape
from pathlib import Path
import base64
import sys


def make_html(shortcuts, accent="#9b6cff", settings=None):
    accent = accent if isinstance(accent, str) and accent.startswith("#") else "#9b6cff"
    settings = settings or {}
    bundle_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
    logo_path = bundle_root / "nebula_logo.png"
    try:
        logo_data = base64.b64encode(logo_path.read_bytes()).decode("ascii")
    except OSError:
        logo_data = ""
    logo_markup = f'<img class="brand-logo" src="data:image/png;base64,{logo_data}" alt="Nebula">' if logo_data else '<span class="brand-mark">N</span>'
    animations = bool(settings.get("animated_background", True)) and not bool(settings.get("resource_saver", False))
    low_effects = bool(settings.get("low_effects", False))
    star_count = {"low": 35, "medium": 75, "high": 130}.get(settings.get("star_density", "medium"), 75)
    if not animations:
        animation_css = "#space,.aurora,.glow{display:none!important}.orbit-core,.orbit-ring{animation:none!important}"
        animation_js = "const ANIMATE=false;"
    else:
        animation_css = ".aurora,.glow{will-change:transform;filter:blur(28px);opacity:.32}"
        animation_js = "const ANIMATE=true;"
    if low_effects:
        animation_css += "form,.tile{backdrop-filter:none!important;box-shadow:none!important}.aurora,.glow{filter:blur(16px)!important;opacity:.18!important}"
    tiles = []
    for title, url in shortcuts:
        safe_title = escape(str(title or url))
        safe_url = escape(str(url), quote=True)
        # A small, stable visual mark keeps the shortcut grid consistent without external assets.
        mark = escape((str(title or url).strip()[:1] or "✦").upper())
        tiles.append(
            f'<a class="tile" href="{safe_url}" title="{safe_title}">'
            f'<span class="tile-icon">{mark}</span><span class="tile-title">{safe_title}</span>'
            f'<span class="tile-url">{escape(str(url).replace("https://", "").replace("http://", ""))}</span></a>'
        )
    if not tiles:
        tiles = ['<div class="empty"><span class="empty-icon">✦</span><b>Twoja przestrzeń dopiero czeka</b><span>Dodaj skróty do ulubionych stron, aby mieć je zawsze pod ręką.</span></div>']

    return f"""<!doctype html>
<html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark"><title>Nowa karta</title>
<style>
{animation_css}
:root{{--accent:{accent};--accent-rgb:155,108,255;--text:#f7f5ff;--muted:#aaa6c4;--panel:rgba(18,17,35,.68);--line:rgba(211,198,255,.15)}}
*{{box-sizing:border-box}}
html,body{{margin:0;min-height:100%;background:#05040c;color:var(--text);font:15px/1.5 'Segoe UI',Inter,Arial,sans-serif}}
body{{min-height:100vh;overflow-x:hidden;background:radial-gradient(ellipse at 50% 38%,#17102c 0%,#0a0816 43%,#05040b 78%);isolation:isolate}}
#space{{position:fixed;inset:0;width:100%;height:100%;z-index:-3;pointer-events:none}}
.aurora{{position:fixed;z-index:-2;pointer-events:none;inset:-25%;filter:blur(62px);opacity:.5;background:conic-gradient(from 30deg at 50% 50%,transparent 0deg,rgba(102,65,255,.13) 55deg,rgba(38,191,215,.11) 115deg,transparent 165deg,rgba(211,65,255,.12) 230deg,transparent 310deg);animation:aurora 24s ease-in-out infinite alternate;transform-origin:center}}
.glow{{position:fixed;z-index:-1;pointer-events:none;width:40vw;height:40vw;max-width:580px;max-height:580px;border-radius:50%;filter:blur(90px);opacity:.17;background:var(--accent);left:calc(50% - 20vw);top:5vh;animation:glow 13s ease-in-out infinite alternate}}
@keyframes aurora{{0%{{transform:rotate(-12deg) scale(.9) translate(-2%,1%)}}100%{{transform:rotate(18deg) scale(1.13) translate(3%,-2%)}}}}
@keyframes glow{{0%{{transform:translate(-10px,0) scale(.85);opacity:.12}}100%{{transform:translate(30px,25px) scale(1.1);opacity:.23}}}}
main{{width:min(1080px,100%);margin:auto;padding:28px 30px 40px}}
header{{display:flex;justify-content:space-between;align-items:center;gap:16px;color:#d5cdef}}
.brand{{display:flex;align-items:center;gap:10px;font-size:12px;font-weight:800;letter-spacing:2.1px}}
.brand-mark{{width:32px;height:32px;display:grid;place-items:center;border:1px solid rgba(208,184,255,.28);border-radius:11px;background:linear-gradient(135deg,rgba(155,108,255,.24),rgba(77,206,224,.08));color:#e8dcff;font-size:18px;box-shadow:0 0 25px rgba(155,108,255,.12)}}.brand-logo{{width:34px;height:34px;object-fit:cover;border-radius:10px;box-shadow:0 0 20px rgba(155,108,255,.22)}}
.clockbox{{text-align:right}}.clock{{font-size:21px;font-weight:650;letter-spacing:.5px;font-variant-numeric:tabular-nums}}.date{{font-size:11px;color:var(--muted);letter-spacing:.6px}}
.hero{{text-align:center;padding:clamp(48px,8vh,88px) 0 30px}}
.orbit{{height:70px;width:70px;margin:0 auto 14px;position:relative;display:grid;place-items:center}}
.orbit-core{{font-size:36px;filter:drop-shadow(0 0 16px rgba(180,139,255,.7));animation:float 5s ease-in-out infinite}}
.orbit-ring{{position:absolute;inset:2px;border:1px solid rgba(187,156,255,.4);border-radius:50%;transform:rotate(-25deg) scaleY(.37);animation:spin 14s linear infinite}}
.orbit-ring:after{{content:'';position:absolute;width:7px;height:7px;border-radius:50%;background:#a9f2ff;box-shadow:0 0 13px #7be9ff;top:5px;left:9px}}
@keyframes spin{{to{{transform:rotate(335deg) scaleY(.37)}}}}@keyframes float{{0%,100%{{transform:translateY(0)}}50%{{transform:translateY(-7px)}}}}
h1{{font-size:clamp(42px,6vw,65px);line-height:1.08;letter-spacing:-2.7px;margin:0;font-weight:750;background:linear-gradient(110deg,#fff 20%,#d8c6ff 53%,#a4eaff 90%);-webkit-background-clip:text;background-clip:text;color:transparent}}
.subtitle{{color:#b8b1d1;margin:13px 0 27px;font-size:15px}}
.search-wrap{{max-width:730px;margin:0 auto;position:relative}}
.search-wrap:before{{content:'';position:absolute;inset:-2px;border-radius:19px;background:linear-gradient(110deg,rgba(155,108,255,.62),rgba(90,206,235,.28),rgba(219,115,255,.42));opacity:.72;filter:blur(13px);z-index:-1}}
form{{display:flex;align-items:center;gap:10px;background:rgba(15,14,27,.88);border:1px solid rgba(214,201,255,.24);border-radius:16px;padding:8px 9px 8px 17px;box-shadow:0 18px 65px rgba(0,0,0,.3),inset 0 1px rgba(255,255,255,.04);backdrop-filter:blur(22px);transition:border-color .2s,transform .2s}}
form:focus-within{{border-color:rgba(190,157,255,.75);transform:translateY(-1px)}}.search-symbol{{color:#bda0ff;font-size:21px;flex:0 0 auto}}
.search{{flex:1;min-width:0;border:0;outline:0;background:transparent;color:#fff;font:inherit;font-size:15px;padding:9px 2px}}
.search::placeholder{{color:#88839f}}.hint{{font-size:10px;white-space:nowrap;color:#77718f;border:1px solid #353047;border-radius:6px;padding:3px 6px}}
.go{{border:0;border-radius:11px;padding:11px 17px;background:linear-gradient(135deg,var(--accent),#7462e8);color:white;font-weight:700;cursor:pointer;box-shadow:0 5px 20px rgba(116,98,232,.22);transition:transform .2s,filter .2s}}.go:hover{{transform:translateY(-1px);filter:brightness(1.12)}}
.suggest{{display:flex;justify-content:center;gap:9px;flex-wrap:wrap;margin-top:15px}}.suggest button{{background:rgba(17,16,31,.54);border:1px solid rgba(199,184,244,.12);color:#c3bdd9;border-radius:999px;padding:6px 11px;font:12px 'Segoe UI',Arial,sans-serif;cursor:pointer;transition:all .2s}}.suggest button:hover{{background:rgba(155,108,255,.16);border-color:rgba(183,151,255,.42);color:#fff}}
.section{{display:flex;justify-content:space-between;align-items:center;gap:14px;margin:43px 0 15px}}.section-title{{display:flex;align-items:center;gap:10px;font-size:11px;font-weight:800;letter-spacing:1.8px;color:#d5cdec}}.section-title:before{{content:'';height:18px;width:3px;border-radius:5px;background:linear-gradient(#bda0ff,#6be1ef);box-shadow:0 0 12px rgba(155,108,255,.6)}}
.add{{background:rgba(24,21,43,.72);color:#e5ddfa;border:1px solid rgba(207,188,255,.2);border-radius:10px;padding:8px 12px;cursor:pointer;font:12px 'Segoe UI',Arial;transition:all .2s}}.add:hover{{border-color:var(--accent);background:rgba(155,108,255,.15);transform:translateY(-1px)}}
.tiles{{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:13px}}
.tile{{position:relative;min-width:0;min-height:128px;text-decoration:none;color:#f1edff;background:linear-gradient(145deg,rgba(29,26,48,.75),rgba(13,12,24,.7));border:1px solid rgba(207,194,245,.13);border-radius:17px;padding:17px 14px 14px;display:flex;flex-direction:column;align-items:flex-start;gap:9px;overflow:hidden;backdrop-filter:blur(12px);transition:transform .22s,border-color .22s,background .22s,box-shadow .22s}}
.tile:before{{content:'';position:absolute;inset:0;background:radial-gradient(circle at 10% 0,rgba(155,108,255,.13),transparent 65%);opacity:.65;pointer-events:none}}.tile:hover{{transform:translateY(-4px);border-color:rgba(183,151,255,.55);background:linear-gradient(145deg,rgba(40,33,67,.9),rgba(17,15,31,.9));box-shadow:0 12px 35px rgba(0,0,0,.22),0 0 25px rgba(155,108,255,.08)}}
.tile-icon{{width:39px;height:39px;display:grid;place-items:center;border-radius:13px;background:linear-gradient(135deg,rgba(155,108,255,.25),rgba(91,202,226,.11));border:1px solid rgba(207,190,255,.18);color:#e0d2ff;font-size:17px;font-weight:750;box-shadow:inset 0 1px rgba(255,255,255,.06)}}.tile-title{{font-size:13px;font-weight:650;max-width:100%;overflow-wrap:anywhere}}.tile-url{{font-size:10px;color:#827c9d;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
.empty{{grid-column:1/-1;display:flex;flex-direction:column;align-items:center;gap:7px;padding:27px;text-align:center;color:#aaa2c5;border:1px dashed rgba(194,174,239,.23);border-radius:17px;background:rgba(17,15,29,.38)}}.empty-icon{{font-size:25px;color:#bca0ff}}.empty b{{color:#e7defa;font-size:14px}}.empty span:last-child{{font-size:12px}}
.footer{{display:flex;justify-content:space-between;gap:12px;margin-top:32px;padding-top:17px;border-top:1px solid rgba(199,184,244,.1);font-size:10px;color:#77718f}}.footer span:last-child{{text-align:right}}
@media(max-width:620px){{main{{padding:19px 15px 28px}}.hero{{padding-top:48px}}.hint{{display:none}}.go{{padding:10px 12px}}.tiles{{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}}.tile{{min-height:116px}}.footer{{flex-direction:column}}.footer span:last-child{{text-align:left}}}}
@media(prefers-reduced-motion:reduce){{*,*:before,*:after{{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition:none!important}}}}
</style></head><body>
<canvas id="space" aria-hidden="true"></canvas><div class="aurora"></div><div class="glow"></div>
<main><header><div class="brand"><span class="brand-mark">✦</span><span>NEBULA <span style="color:#8e83b5">/ BROWSER</span></span></div><div class="clockbox"><div class="clock" id="clock">--:--</div><div class="date" id="date">Dobrego dnia</div></div></header>
<section class="hero"><div class="orbit"><span class="orbit-core">✦</span><span class="orbit-ring"></span></div><h1>Witaj w Nebuli</h1><p class="subtitle">Twoje miejsce w sieci. Czysto, szybko, po Twojemu.</p>
<div class="search-wrap"><form onsubmit="event.preventDefault();let q=document.getElementById('search').value.trim();if(q)location.href='nebula://search?q='+encodeURIComponent(q)"><span class="search-symbol">⌕</span><input id="search" class="search" autofocus autocomplete="off" spellcheck="false" placeholder="Czego dziś szukamy? Wpisz adres lub frazę" aria-label="Wyszukaj lub wpisz adres"><span class="hint">ENTER ↵</span><button class="go" type="submit">Szukaj&nbsp; ↗</button></form></div>
<div class="suggest"><button onclick="searchFor('YouTube')">▶ YouTube</button><button onclick="searchFor('pogoda')">☼ Pogoda</button><button onclick="searchFor('wiadomości')">◉ Wiadomości</button><button onclick="searchFor('Wikipedia')">◇ Wikipedia</button></div></section>
<div class="section"><div class="section-title">TWOJE SKRÓTY</div><button class="add" onclick="addShortcut()">＋ &nbsp;Dodaj skrót</button></div>
<div class="tiles">{"".join(tiles)}</div>
<div class="footer"><span>✦ Nebula Browser <span id="greeting">— miłego przeglądania</span></span><span>Twoja przestrzeń, Twój rytm.</span></div></main>
<script>
function addShortcut(){{let title=prompt('Nazwa skrótu (np. YouTube):');if(title===null)return;let url=prompt('Adres strony (np. https://www.youtube.com):');if(url===null||!url.trim())return;url=url.trim();if(!/^https?:\\/\\//i.test(url))url='https://'+url;location.href='nebula://add-shortcut?title='+encodeURIComponent(title.trim()||url)+'&url='+encodeURIComponent(url)}}
function searchFor(q){{document.getElementById('search').value=q;document.getElementById('search').focus()}}
function updateClock(){{const now=new Date();document.getElementById('clock').textContent=now.toLocaleTimeString('pl-PL',{{hour:'2-digit',minute:'2-digit'}});document.getElementById('date').textContent=now.toLocaleDateString('pl-PL',{{weekday:'long',day:'numeric',month:'long'}});const h=now.getHours();document.getElementById('greeting').textContent=h<12?'— dobrego poranka':h<18?'— miłego dnia':'— dobrego wieczoru'}}updateClock();setInterval(updateClock,15000);
// Lightweight procedural starfield: bounded work per frame.
{animation_js}
(()=>{{const canvas=document.getElementById('space'),ctx=canvas.getContext('2d');let w=0,h=0,dpr=1,stars=[],raf=0;const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches||!ANIMATE;function resize(){{dpr=Math.min(window.devicePixelRatio||1,1.5);w=innerWidth;h=innerHeight;canvas.width=Math.floor(w*dpr);canvas.height=Math.floor(h*dpr);canvas.style.width=w+'px';canvas.style.height=h+'px';ctx.setTransform(dpr,0,0,dpr,0,0);stars=Array.from({{length:Math.min({star_count},Math.floor(w*h/14000))}},()=>({{x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.35+.25,a:Math.random()*.55+.2,p:Math.random()*6.28,s:(Math.random()*.006+.002)*(Math.random()>.5?1:-1),drift:(Math.random()*.12+.025)}}))}}function draw(){{ctx.clearRect(0,0,w,h);for(const s of stars){{s.p+=s.s;if(!reduced)s.y-=s.drift*.18;if(s.y< -3)s.y=h+3;const alpha=s.a*(.68+.32*Math.sin(s.p));ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fillStyle='rgba(220,215,255,'+alpha+')';ctx.fill();if(s.r>1.15){{ctx.beginPath();ctx.moveTo(s.x-3,s.y);ctx.lineTo(s.x+3,s.y);ctx.moveTo(s.x,s.y-3);ctx.lineTo(s.x,s.y+3);ctx.strokeStyle='rgba(172,151,255,'+(alpha*.45)+')';ctx.lineWidth=.5;ctx.stroke()}}}}if(!reduced)raf=requestAnimationFrame(draw)}}resize();draw();window.addEventListener('resize',()=>{{cancelAnimationFrame(raf);resize();draw()}},{{passive:true}})}})();
</script></body></html>"""


def add_shortcut(parent):
    d = QDialog(parent)
    d.setWindowTitle("Dodaj skrót do Szybkiego startu")
    f = QFormLayout(d)
    name = QLineEdit()
    name.setPlaceholderText("np. YouTube")
    url = QLineEdit()
    url.setPlaceholderText("https://www.youtube.com")
    f.addRow("Nazwa", name)
    f.addRow("Adres", url)
    b = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
    b.accepted.connect(d.accept)
    b.rejected.connect(d.reject)
    f.addRow(b)
    if d.exec() == QDialog.DialogCode.Accepted:
        u = url.text().strip()
        if u and not u.startswith(("https://", "http://")):
            u = "https://" + u
        if u:
            return name.text().strip() or u, u
    return None
