import sqlite3
from nebula.config import DB
class Store:
    def __init__(self):
        self.db=sqlite3.connect(DB)
        self.db.execute("CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY,url TEXT,title TEXT,visited DATETIME DEFAULT CURRENT_TIMESTAMP)")
        self.db.execute("CREATE TABLE IF NOT EXISTS bookmarks(url TEXT PRIMARY KEY,title TEXT)")
        self.db.execute("CREATE TABLE IF NOT EXISTS shortcuts(url TEXT PRIMARY KEY,title TEXT,position INTEGER DEFAULT 0)")
        self.db.commit()
    def visit(self,u,t):
        if u.startswith(("https://","http://")):
            self.db.execute("INSERT INTO history(url,title) VALUES(?,?)",(u,t or u)); self.db.commit()
    def history(self): return self.db.execute("SELECT title,url,visited FROM history ORDER BY id DESC LIMIT 1000").fetchall()
    def clear_history(self): self.db.execute("DELETE FROM history"); self.db.commit()
    def bookmarks(self): return self.db.execute("SELECT title,url FROM bookmarks ORDER BY title").fetchall()
    def add_bookmark(self,u,t): self.db.execute("INSERT OR REPLACE INTO bookmarks(url,title) VALUES(?,?)",(u,t or u)); self.db.commit()
    def remove_bookmark(self,u): self.db.execute("DELETE FROM bookmarks WHERE url=?",(u,)); self.db.commit()
    def shortcuts(self): return self.db.execute("SELECT title,url FROM shortcuts ORDER BY position,title").fetchall()
    def add_shortcut(self,u,t): self.db.execute("INSERT OR REPLACE INTO shortcuts(url,title,position) VALUES(?,?,COALESCE((SELECT MAX(position)+1 FROM shortcuts),0))",(u,t or u)); self.db.commit()
    def remove_shortcut(self,u): self.db.execute("DELETE FROM shortcuts WHERE url=?",(u,)); self.db.commit()
