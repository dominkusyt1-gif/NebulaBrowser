import json
from pathlib import Path
from PySide6.QtCore import QStandardPaths
DATA = Path(QStandardPaths.writableLocation(QStandardPaths.AppDataLocation)) / "NebulaBrowser"
DATA.mkdir(parents=True, exist_ok=True)
CONFIG = DATA / "settings.json"
DB = DATA / "nebula.sqlite3"
DEFAULT = {"search":"Google","home":"https://www.google.com","accent":"#9b6cff",
           "download":str(Path.home()/"Downloads"),"ask_download":False,"javascript":True,
           "version":"0.8.0","update_notifications":False,"update_release_api":"",
           "animated_background":True,"low_effects":False,"star_density":"medium",
           "load_images":True,"cache_mb":256,"resource_saver":False,"process_priority_low":False,
           "restore_session":True,"theme":"black","tab_width":"extra"}
def load():
    try: return {**DEFAULT, **json.loads(CONFIG.read_text(encoding="utf-8"))}
    except Exception: return DEFAULT.copy()
def save(cfg): CONFIG.write_text(json.dumps(cfg,indent=2,ensure_ascii=False),encoding="utf-8")
