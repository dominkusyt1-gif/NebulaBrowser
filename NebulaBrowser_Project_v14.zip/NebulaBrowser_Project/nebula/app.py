import sys
from PySide6.QtWidgets import QApplication
from nebula.ui.main_window import MainWindow
def main():
    app=QApplication(sys.argv);app.setApplicationName("Nebula Browser");app.setOrganizationName("Nebula")
    w=MainWindow();w.show();sys.exit(app.exec())
