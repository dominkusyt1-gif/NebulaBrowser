from PySide6.QtCore import QUrl, QUrlQuery
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings

class NebulaPage(QWebEnginePage):
    def __init__(self, win, profile, parent=None):
        super().__init__(profile, parent)
        self.win = win

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        if url.scheme() == "nebula":
            query = QUrlQuery(url)
            if url.host() == "add-shortcut":
                self.win.handle_add_shortcut(query.queryItemValue("title"), query.queryItemValue("url"))
            elif url.host() == "search":
                self.win.handle_start_search(query.queryItemValue("q"))
            return False
        return super().acceptNavigationRequest(url, nav_type, is_main_frame)

class BrowserView(QWebEngineView):
    def __init__(self, win, profile):
        super().__init__()
        self.win = win
        self.setPage(NebulaPage(win, profile, self))
        self.urlChanged.connect(lambda u: win.url_changed(self, u))
        self.titleChanged.connect(lambda t: win.title_changed(self, t))
        self.iconChanged.connect(lambda icon: win._sync_top_tabs())
        self.loadProgress.connect(win.progress.setValue)
        self.loadStarted.connect(win.progress.show)
        self.loadFinished.connect(lambda ok: win.progress.hide())
        self.page().settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, win.cfg["javascript"])

    def createWindow(self, kind):
        return self.win.add_tab()
