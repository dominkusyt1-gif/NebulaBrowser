NEBULA BROWSER — Windows
1. Rozpakuj ZIP.
2. Otwórz CMD w folderze NebulaBrowser_Project.
3. Uruchom: python -m pip install -r requirements.txt
4. Uruchom: python main.py lub kliknij run_nebula.bat

Wymaga Windows 10/11, Pythona 3.13 i internetu.
Funkcje: prawdziwe strony WWW przez Qt WebEngine, karty, wyszukiwanie,
historia, zakładki, pobieranie, ustawienia otwierane w osobnej karcie oraz przypinane skróty na nowej karcie. Lewy pasek boczny został usunięty.
Skróty: Ctrl+T, Ctrl+W, Ctrl+L, Ctrl+D, Ctrl+H, Ctrl+B.
To projekt hobbystyczny i baza do rozwoju, nie pełny zamiennik Chrome.
Kod sprawdzono składniowo, ale wymaga testu na docelowym Windowsie.

Budowanie EXE:
- Na Windows 10/11 z Pythonem 3.13 uruchom build_exe_windows.bat.
- Po zakończeniu sprawdź dist\NebulaBrowser\NebulaBrowser.exe.
- Budowanie EXE nie zostało wykonane w tym środowisku; skrypt buduje je na Windows.

Aktualizacje:
- W Ustawieniach można włączyć informowanie o aktualizacjach i ręcznie kliknąć „Sprawdź aktualizacje”.
- Aby sprawdzanie działało, wpisz oficjalny adres API wydań w polu „Adres API wydań” w Ustawienia → Aktualizacje i zapisz ustawienia.
- Aplikacja nie instaluje aktualizacji bez potwierdzenia użytkownika. Samo pobranie/instalacja nie jest jeszcze automatycznie wdrożone.


NOWOŚCI v14
- Ikona Nebula Browser: nebula.ico (używana w oknie i przy budowaniu EXE).
- Skrypt budowania próbuje najpierw `py -3.13`, a potem `python`, więc działa także bez launchera `py`.
- Ustawienia wydajności: limit pamięci podręcznej HTTP, wyłączanie obrazów stron, tryb oszczędzania animacji karty startowej i niższy priorytet procesu w Windows (nie jest to twardy limit RAM/CPU).
- Aktualizacje: po wyrażeniu zgody i wpisaniu adresu API oficjalnych wydań aplikacja sprawdza dostępność aktualizacji w tle przy starcie. Samo pobranie nadal wymaga potwierdzenia; nie ma automatycznej instalacji.
- Do działania aktualizatora potrzebny jest prawdziwy adres repozytorium, np. https://api.github.com/repos/OWNER/REPO/releases/latest. Nie wpisuj przykładowego OWNER/REPO.
