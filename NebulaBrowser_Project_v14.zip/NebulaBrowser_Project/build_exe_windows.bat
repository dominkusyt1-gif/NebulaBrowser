@echo off
chcp 65001 >nul
title Nebula Browser - EXE Builder
cd /d "%~dp0"
echo ============================================
echo   Nebula Browser - tworzenie pliku EXE
echo ============================================
echo.
set "PY=py -3.13"
py -3.13 --version >nul 2>&1
if errorlevel 1 (
  set "PY=python"
  python --version >nul 2>&1
  if errorlevel 1 (
    echo BLAD: Nie znaleziono Pythona. Zainstaluj Python 3.13 x64 i zaznacz Add Python to PATH.
    goto error
  )
)
%PY% -m pip install --upgrade pip
if errorlevel 1 goto error
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto error
%PY% -m pip install pyinstaller
if errorlevel 1 goto error
%PY% -m PyInstaller --noconfirm --clean --windowed --name "NebulaBrowser" --icon=nebula.ico --add-data "nebula.ico;." --add-data "nebula_logo.png;." --collect-all PySide6 --collect-all shiboken6 main.py
if errorlevel 1 goto error
echo.
echo Gotowe! Plik EXE: dist\NebulaBrowser\NebulaBrowser.exe
echo Zachowaj caly folder dist\NebulaBrowser.
pause
exit /b 0
:error
echo.
echo Budowanie nie powiodlo sie. Sprawdz pierwszy komunikat bledu.
pause
exit /b 1
